package ch.samt.collectionGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollectionGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
