package ch.samt.collectionGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollectionGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollectionGameApplication.class, args);
	}

}
